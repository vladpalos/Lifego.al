require('derby').run(__dirname + '/lib/server');
