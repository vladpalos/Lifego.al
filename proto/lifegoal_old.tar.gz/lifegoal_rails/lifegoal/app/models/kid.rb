class Kid < ActiveRecord::Base

end
