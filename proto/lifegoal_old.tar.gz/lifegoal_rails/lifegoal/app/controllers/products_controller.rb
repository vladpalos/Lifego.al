class ProductsController < ApplicationController
	def new 
	end
end
