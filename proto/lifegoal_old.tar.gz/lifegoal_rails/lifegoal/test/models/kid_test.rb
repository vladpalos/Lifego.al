require 'test_helper'

class KidTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
