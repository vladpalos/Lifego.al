# Be sure to restart your server when you modify this file.

Lifegoal::Application.config.session_store :cookie_store, key: '_lifegoal_session'
